package com.tpmetodosagiles.tpmetodosagiles;

public @interface EnableWebSecurity {

}
