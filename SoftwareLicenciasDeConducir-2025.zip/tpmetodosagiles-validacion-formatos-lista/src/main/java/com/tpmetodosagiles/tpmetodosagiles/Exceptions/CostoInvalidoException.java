package com.tpmetodosagiles.tpmetodosagiles.Exceptions;

public class CostoInvalidoException extends Exception {
    public CostoInvalidoException(String mensajeException){
        super(mensajeException);
    }
}
