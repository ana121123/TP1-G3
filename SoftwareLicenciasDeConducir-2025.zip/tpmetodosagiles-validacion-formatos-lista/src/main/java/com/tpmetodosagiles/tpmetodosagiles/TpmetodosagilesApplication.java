package com.tpmetodosagiles.tpmetodosagiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpmetodosagilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpmetodosagilesApplication.class, args);
	}


}
