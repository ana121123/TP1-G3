package com.tpmetodosagiles.tpmetodosagiles.enums;

public enum Subcategoria {

}
