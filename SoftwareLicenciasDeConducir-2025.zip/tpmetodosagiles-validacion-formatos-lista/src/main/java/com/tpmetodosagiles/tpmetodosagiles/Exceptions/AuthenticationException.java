package com.tpmetodosagiles.tpmetodosagiles.Exceptions;

public class AuthenticationException extends RuntimeException{
    
}
